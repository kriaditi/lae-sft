# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=496)
  - excluded for short-distractors: 0
  - gold via fallback (`pos_item_ids[0]`): 142 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA H100 PCIe  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 43.6 min  peak VRAM: 19.31 GB
- reader cache: unique=6448 / total_cells=6448 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 496 | 62.70% | [58.36, 66.84] | 185 |
| **k3_first** | 3 | first | 0 | 496 | 58.47% | [54.08, 62.72] | 206 |
| **k3_middle** | 3 | middle | 1 | 496 | 60.08% | [55.71, 64.30] | 198 |
| **k3_last** | 3 | last | 2 | 496 | 60.89% | [56.52, 65.08] | 194 |
| **k5_first** | 5 | first | 0 | 496 | 58.67% | [54.29, 62.92] | 205 |
| **k5_middle** | 5 | middle | 2 | 496 | 57.86% | [53.47, 62.13] | 209 |
| **k5_last** | 5 | last | 4 | 496 | 58.87% | [54.49, 63.12] | 204 |
| **k10_first** | 10 | first | 0 | 496 | 53.83% | [49.43, 58.17] | 229 |
| **k10_middle** | 10 | middle | 4 | 496 | 55.85% | [51.45, 60.16] | 219 |
| **k10_last** | 10 | last | 9 | 496 | 53.23% | [48.83, 57.58] | 232 |
| **k20_first** | 20 | first | 0 | 496 | 51.41% | [47.02, 55.78] | 241 |
| **k20_middle** | 20 | middle | 9 | 496 | 51.61% | [47.22, 55.98] | 240 |
| **k20_last** | 20 | last | 19 | 496 | 51.41% | [47.02, 55.78] | 241 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 354 | 66.95% | [61.89, 71.64] | 117 |
| **k3_first** | 3 | first | 0 | 354 | 61.86% | [56.70, 66.77] | 135 |
| **k3_middle** | 3 | middle | 1 | 354 | 64.12% | [59.00, 68.94] | 127 |
| **k3_last** | 3 | last | 2 | 354 | 64.97% | [59.87, 69.76] | 124 |
| **k5_first** | 5 | first | 0 | 354 | 62.43% | [57.28, 67.32] | 133 |
| **k5_middle** | 5 | middle | 2 | 354 | 61.30% | [56.13, 66.23] | 137 |
| **k5_last** | 5 | last | 4 | 354 | 62.71% | [57.56, 67.59] | 132 |
| **k10_first** | 10 | first | 0 | 354 | 57.91% | [52.71, 62.94] | 149 |
| **k10_middle** | 10 | middle | 4 | 354 | 59.89% | [54.70, 64.86] | 142 |
| **k10_last** | 10 | last | 9 | 354 | 57.06% | [51.86, 62.12] | 152 |
| **k20_first** | 20 | first | 0 | 354 | 55.37% | [50.16, 60.46] | 158 |
| **k20_middle** | 20 | middle | 9 | 354 | 55.37% | [50.16, 60.46] | 158 |
| **k20_last** | 20 | last | 19 | 354 | 55.93% | [50.72, 61.01] | 156 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 185 | 47.6% | 0.0% | 0.0% | 52.4% | - |
| k3_first | 3 | first | 206 | 31.6% | 15.0% | 10.7% | 42.7% | 0 |
| k3_middle | 3 | middle | 198 | 35.4% | 14.6% | 9.6% | 40.4% | 0 |
| k3_last | 3 | last | 194 | 36.6% | 14.9% | 8.8% | 39.7% | 0 |
| k5_first | 5 | first | 205 | 27.3% | 22.0% | 9.8% | 41.0% | 1 |
| k5_middle | 5 | middle | 209 | 30.1% | 22.5% | 11.0% | 36.4% | 1 |
| k5_last | 5 | last | 204 | 31.9% | 23.0% | 10.8% | 34.3% | 1 |
| k10_first | 10 | first | 229 | 21.8% | 30.1% | 15.7% | 32.3% | 3 |
| k10_middle | 10 | middle | 219 | 23.7% | 29.2% | 15.1% | 32.0% | 3 |
| k10_last | 10 | last | 232 | 21.1% | 31.9% | 15.1% | 31.9% | 3 |
| k20_first | 20 | first | 241 | 17.4% | 40.7% | 14.5% | 27.4% | 6 |
| k20_middle | 20 | middle | 240 | 17.1% | 39.2% | 16.2% | 27.5% | 5 |
| k20_last | 20 | last | 241 | 14.9% | 41.5% | 15.8% | 27.8% | 6 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
