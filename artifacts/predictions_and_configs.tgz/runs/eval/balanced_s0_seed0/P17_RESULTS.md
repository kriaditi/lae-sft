# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=496)
  - excluded for short-distractors: 0
  - gold via fallback (`pos_item_ids[0]`): 142 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA H100 PCIe  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 43.4 min  peak VRAM: 19.31 GB
- reader cache: unique=6448 / total_cells=6448 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 496 | 64.52% | [60.21, 68.60] | 176 |
| **k3_first** | 3 | first | 0 | 496 | 58.67% | [54.29, 62.92] | 205 |
| **k3_middle** | 3 | middle | 1 | 496 | 61.09% | [56.73, 65.28] | 193 |
| **k3_last** | 3 | last | 2 | 496 | 60.89% | [56.52, 65.08] | 194 |
| **k5_first** | 5 | first | 0 | 496 | 57.46% | [53.07, 61.74] | 211 |
| **k5_middle** | 5 | middle | 2 | 496 | 58.67% | [54.29, 62.92] | 205 |
| **k5_last** | 5 | last | 4 | 496 | 58.87% | [54.49, 63.12] | 204 |
| **k10_first** | 10 | first | 0 | 496 | 54.23% | [49.83, 58.57] | 227 |
| **k10_middle** | 10 | middle | 4 | 496 | 55.85% | [51.45, 60.16] | 219 |
| **k10_last** | 10 | last | 9 | 496 | 55.04% | [50.64, 59.36] | 223 |
| **k20_first** | 20 | first | 0 | 496 | 49.80% | [45.42, 54.18] | 249 |
| **k20_middle** | 20 | middle | 9 | 496 | 50.40% | [46.02, 54.78] | 246 |
| **k20_last** | 20 | last | 19 | 496 | 50.20% | [45.82, 54.58] | 247 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 354 | 68.64% | [63.63, 73.26] | 111 |
| **k3_first** | 3 | first | 0 | 354 | 61.30% | [56.13, 66.23] | 137 |
| **k3_middle** | 3 | middle | 1 | 354 | 64.97% | [59.87, 69.76] | 124 |
| **k3_last** | 3 | last | 2 | 354 | 64.97% | [59.87, 69.76] | 124 |
| **k5_first** | 5 | first | 0 | 354 | 61.30% | [56.13, 66.23] | 137 |
| **k5_middle** | 5 | middle | 2 | 354 | 62.71% | [57.56, 67.59] | 132 |
| **k5_last** | 5 | last | 4 | 354 | 62.99% | [57.85, 67.86] | 131 |
| **k10_first** | 10 | first | 0 | 354 | 57.63% | [52.42, 62.67] | 150 |
| **k10_middle** | 10 | middle | 4 | 354 | 60.17% | [54.99, 65.13] | 141 |
| **k10_last** | 10 | last | 9 | 354 | 59.89% | [54.70, 64.86] | 142 |
| **k20_first** | 20 | first | 0 | 354 | 53.39% | [48.18, 58.52] | 165 |
| **k20_middle** | 20 | middle | 9 | 354 | 55.08% | [49.88, 60.18] | 159 |
| **k20_last** | 20 | last | 19 | 354 | 55.08% | [49.88, 60.18] | 159 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 176 | 50.0% | 0.0% | 0.0% | 50.0% | - |
| k3_first | 3 | first | 205 | 31.2% | 21.5% | 12.7% | 34.6% | 0 |
| k3_middle | 3 | middle | 193 | 33.7% | 18.7% | 11.4% | 36.3% | 0 |
| k3_last | 3 | last | 194 | 35.6% | 18.0% | 11.3% | 35.1% | 0 |
| k5_first | 5 | first | 211 | 27.0% | 25.6% | 15.2% | 32.2% | 1 |
| k5_middle | 5 | middle | 205 | 27.3% | 24.9% | 14.1% | 33.7% | 1 |
| k5_last | 5 | last | 204 | 27.0% | 23.5% | 14.7% | 34.8% | 1 |
| k10_first | 10 | first | 227 | 19.4% | 39.2% | 16.3% | 25.1% | 2 |
| k10_middle | 10 | middle | 219 | 21.5% | 38.4% | 17.4% | 22.8% | 3 |
| k10_last | 10 | last | 223 | 22.0% | 37.7% | 17.0% | 23.3% | 3 |
| k20_first | 20 | first | 249 | 11.6% | 52.2% | 16.5% | 19.7% | 5 |
| k20_middle | 20 | middle | 246 | 16.7% | 46.7% | 16.7% | 19.9% | 4 |
| k20_last | 20 | last | 247 | 17.0% | 44.5% | 17.0% | 21.5% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
