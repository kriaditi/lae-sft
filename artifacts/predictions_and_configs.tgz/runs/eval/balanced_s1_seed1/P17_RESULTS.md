# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=496)
  - excluded for short-distractors: 0
  - gold via fallback (`pos_item_ids[0]`): 142 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA H100 PCIe  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 43.8 min  peak VRAM: 19.31 GB
- reader cache: unique=6448 / total_cells=6448 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 496 | 64.11% | [59.80, 68.21] | 178 |
| **k3_first** | 3 | first | 0 | 496 | 57.86% | [53.47, 62.13] | 209 |
| **k3_middle** | 3 | middle | 1 | 496 | 60.48% | [56.12, 64.69] | 196 |
| **k3_last** | 3 | last | 2 | 496 | 60.69% | [56.32, 64.89] | 195 |
| **k5_first** | 5 | first | 0 | 496 | 56.65% | [52.26, 60.95] | 215 |
| **k5_middle** | 5 | middle | 2 | 496 | 58.27% | [53.88, 62.53] | 207 |
| **k5_last** | 5 | last | 4 | 496 | 58.87% | [54.49, 63.12] | 204 |
| **k10_first** | 10 | first | 0 | 496 | 54.44% | [50.04, 58.77] | 226 |
| **k10_middle** | 10 | middle | 4 | 496 | 55.24% | [50.84, 59.56] | 222 |
| **k10_last** | 10 | last | 9 | 496 | 53.43% | [49.03, 57.77] | 231 |
| **k20_first** | 20 | first | 0 | 496 | 52.42% | [48.02, 56.78] | 236 |
| **k20_middle** | 20 | middle | 9 | 496 | 50.20% | [45.82, 54.58] | 247 |
| **k20_last** | 20 | last | 19 | 496 | 51.21% | [46.82, 55.58] | 242 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 354 | 68.08% | [63.05, 72.72] | 113 |
| **k3_first** | 3 | first | 0 | 354 | 62.15% | [56.99, 67.04] | 134 |
| **k3_middle** | 3 | middle | 1 | 354 | 65.54% | [60.44, 70.30] | 122 |
| **k3_last** | 3 | last | 2 | 354 | 64.97% | [59.87, 69.76] | 124 |
| **k5_first** | 5 | first | 0 | 354 | 61.30% | [56.13, 66.23] | 137 |
| **k5_middle** | 5 | middle | 2 | 354 | 63.28% | [58.14, 68.13] | 130 |
| **k5_last** | 5 | last | 4 | 354 | 62.99% | [57.85, 67.86] | 131 |
| **k10_first** | 10 | first | 0 | 354 | 58.19% | [52.99, 63.22] | 148 |
| **k10_middle** | 10 | middle | 4 | 354 | 59.04% | [53.85, 64.04] | 145 |
| **k10_last** | 10 | last | 9 | 354 | 57.34% | [52.14, 62.39] | 151 |
| **k20_first** | 20 | first | 0 | 354 | 57.06% | [51.86, 62.12] | 152 |
| **k20_middle** | 20 | middle | 9 | 354 | 53.95% | [48.75, 59.08] | 163 |
| **k20_last** | 20 | last | 19 | 354 | 55.08% | [49.88, 60.18] | 159 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 178 | 52.8% | 0.0% | 0.0% | 47.2% | - |
| k3_first | 3 | first | 209 | 33.0% | 17.7% | 11.0% | 38.3% | 0 |
| k3_middle | 3 | middle | 196 | 37.2% | 16.8% | 10.2% | 35.7% | 0 |
| k3_last | 3 | last | 195 | 39.0% | 16.9% | 9.7% | 34.4% | 0 |
| k5_first | 5 | first | 215 | 29.8% | 23.7% | 13.0% | 33.5% | 1 |
| k5_middle | 5 | middle | 207 | 32.4% | 21.3% | 14.0% | 32.4% | 1 |
| k5_last | 5 | last | 204 | 29.9% | 23.5% | 14.2% | 32.4% | 1 |
| k10_first | 10 | first | 226 | 22.6% | 29.2% | 16.8% | 31.4% | 2 |
| k10_middle | 10 | middle | 222 | 23.0% | 32.4% | 16.2% | 28.4% | 3 |
| k10_last | 10 | last | 231 | 21.2% | 31.6% | 16.5% | 30.7% | 3 |
| k20_first | 20 | first | 236 | 18.2% | 36.0% | 19.9% | 25.8% | 4 |
| k20_middle | 20 | middle | 247 | 16.2% | 38.5% | 19.8% | 25.5% | 4 |
| k20_last | 20 | last | 242 | 14.9% | 38.4% | 19.0% | 27.7% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
