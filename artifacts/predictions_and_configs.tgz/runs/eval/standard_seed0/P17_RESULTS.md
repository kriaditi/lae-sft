# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=496)
  - excluded for short-distractors: 0
  - gold via fallback (`pos_item_ids[0]`): 142 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA H100 PCIe  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 42.8 min  peak VRAM: 19.31 GB
- reader cache: unique=6448 / total_cells=6448 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 496 | 64.52% | [60.21, 68.60] | 176 |
| **k3_first** | 3 | first | 0 | 496 | 59.68% | [55.30, 63.90] | 200 |
| **k3_middle** | 3 | middle | 1 | 496 | 59.68% | [55.30, 63.90] | 200 |
| **k3_last** | 3 | last | 2 | 496 | 61.49% | [57.14, 65.67] | 191 |
| **k5_first** | 5 | first | 0 | 496 | 57.66% | [53.27, 61.93] | 210 |
| **k5_middle** | 5 | middle | 2 | 496 | 59.48% | [55.10, 63.71] | 201 |
| **k5_last** | 5 | last | 4 | 496 | 58.87% | [54.49, 63.12] | 204 |
| **k10_first** | 10 | first | 0 | 496 | 55.85% | [51.45, 60.16] | 219 |
| **k10_middle** | 10 | middle | 4 | 496 | 54.64% | [50.24, 58.97] | 225 |
| **k10_last** | 10 | last | 9 | 496 | 54.64% | [50.24, 58.97] | 225 |
| **k20_first** | 20 | first | 0 | 496 | 52.02% | [47.62, 56.38] | 238 |
| **k20_middle** | 20 | middle | 9 | 496 | 51.01% | [46.62, 55.38] | 243 |
| **k20_last** | 20 | last | 19 | 496 | 50.20% | [45.82, 54.58] | 247 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 354 | 69.21% | [64.22, 73.79] | 109 |
| **k3_first** | 3 | first | 0 | 354 | 62.99% | [57.85, 67.86] | 131 |
| **k3_middle** | 3 | middle | 1 | 354 | 63.56% | [58.43, 68.40] | 129 |
| **k3_last** | 3 | last | 2 | 354 | 66.10% | [61.02, 70.84] | 120 |
| **k5_first** | 5 | first | 0 | 354 | 61.58% | [56.42, 66.50] | 136 |
| **k5_middle** | 5 | middle | 2 | 354 | 63.84% | [58.71, 68.67] | 128 |
| **k5_last** | 5 | last | 4 | 354 | 63.28% | [58.14, 68.13] | 130 |
| **k10_first** | 10 | first | 0 | 354 | 59.89% | [54.70, 64.86] | 142 |
| **k10_middle** | 10 | middle | 4 | 354 | 59.04% | [53.85, 64.04] | 145 |
| **k10_last** | 10 | last | 9 | 354 | 59.89% | [54.70, 64.86] | 142 |
| **k20_first** | 20 | first | 0 | 354 | 55.37% | [50.16, 60.46] | 158 |
| **k20_middle** | 20 | middle | 9 | 354 | 54.24% | [49.03, 59.35] | 162 |
| **k20_last** | 20 | last | 19 | 354 | 53.95% | [48.75, 59.08] | 163 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 176 | 57.4% | 0.0% | 0.0% | 42.6% | - |
| k3_first | 3 | first | 200 | 35.5% | 22.5% | 10.5% | 31.5% | 0 |
| k3_middle | 3 | middle | 200 | 37.0% | 20.0% | 11.5% | 31.5% | 0 |
| k3_last | 3 | last | 191 | 39.8% | 16.8% | 11.5% | 31.9% | 0 |
| k5_first | 5 | first | 210 | 29.0% | 26.7% | 14.3% | 30.0% | 1 |
| k5_middle | 5 | middle | 201 | 31.8% | 23.9% | 14.4% | 29.9% | 1 |
| k5_last | 5 | last | 204 | 30.9% | 23.5% | 13.7% | 31.9% | 1 |
| k10_first | 10 | first | 219 | 20.5% | 37.0% | 19.2% | 23.3% | 2 |
| k10_middle | 10 | middle | 225 | 20.4% | 36.0% | 19.1% | 24.4% | 2 |
| k10_last | 10 | last | 225 | 20.0% | 35.1% | 19.1% | 25.8% | 3 |
| k20_first | 20 | first | 238 | 14.3% | 45.0% | 19.3% | 21.4% | 6 |
| k20_middle | 20 | middle | 243 | 14.8% | 42.8% | 19.3% | 23.0% | 6 |
| k20_last | 20 | last | 247 | 14.6% | 41.7% | 20.2% | 23.5% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
